﻿SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS  `if_daily_free`;
CREATE TABLE `if_daily_free` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `match_date` date NOT NULL COMMENT '比赛日',
  `money_start` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '起始资金',
  `money_ing` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '可用资金',
  `money_end` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '收盘资金',
  `amount` int(11) NOT NULL DEFAULT '0' COMMENT '交易单数',
  `amount_win` int(11) NOT NULL DEFAULT '0',
  `his_money_ceil` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '历史最高资金',
  `his_money_floor` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '历史最低资金',
  `reborn` int(11) NOT NULL DEFAULT '0' COMMENT '重生次数',
  `gold` int(11) NOT NULL DEFAULT '0' COMMENT '已赚取的金币',
  `gold_time` int(11) NOT NULL DEFAULT '0' COMMENT '兑换金币次数',
  `profit` decimal(20,2) NOT NULL DEFAULT '0.00',
  `reborn_prize` int(11) NOT NULL DEFAULT '0' COMMENT '每日任务',
  `amount_prize` int(11) NOT NULL DEFAULT '0' COMMENT '每日任务',
  `gold_prize` int(11) NOT NULL DEFAULT '0' COMMENT '每日任务',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`match_date`),
  KEY `user_id_2` (`user_id`),
  KEY `match_date` (`match_date`)
) ENGINE=InnoDB AUTO_INCREMENT=1774 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `if_solo`;
CREATE TABLE `if_solo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `match_date` date NOT NULL COMMENT '比赛日',
  `money_start` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '起始资金',
  `gold` int(11) NOT NULL DEFAULT '0' COMMENT '单个用户的押金',
  `commission` int(11) NOT NULL DEFAULT '10' COMMENT '平台抽成，10%',
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `process_status_id` int(11) NOT NULL DEFAULT '1' COMMENT ' 1进行中，3表示完结，2结算中',
  `user_win_id` bigint(20) NOT NULL DEFAULT '-1' COMMENT '如果有人投降，那么就先赋值',
  `user_id1` bigint(20) NOT NULL DEFAULT '-1',
  `user_id2` bigint(20) NOT NULL DEFAULT '-1',
  `solo_user_id1` bigint(20) NOT NULL DEFAULT '-1',
  `solo_user_id2` bigint(20) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `match_date` (`match_date`),
  KEY `process_status_id` (`process_status_id`),
  KEY `end_time` (`end_time`)
) ENGINE=InnoDB AUTO_INCREMENT=369 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `if_solo_user`;
CREATE TABLE `if_solo_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `solo_id` bigint(20) NOT NULL,
  `match_date` date NOT NULL COMMENT '比赛日',
  `user_id` bigint(20) NOT NULL,
  `money_ing` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '可用资金',
  `money_end` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '收盘资金',
  `amount` int(11) NOT NULL DEFAULT '0' COMMENT '交易单数',
  `amount_win` int(11) NOT NULL DEFAULT '0',
  `his_money_ceil` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '历史最高资金',
  `his_money_floor` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '历史最低资金',
  `profit` decimal(20,2) NOT NULL DEFAULT '0.00',
  `gold_earn` int(11) NOT NULL DEFAULT '0' COMMENT '获胜后获取的金币奖励',
  `gold_margin` int(11) NOT NULL DEFAULT '0' COMMENT '金币押金',
  `opponent_id` bigint(20) NOT NULL DEFAULT '-1' COMMENT '对手',
  `opponent_info` varchar(20) NOT NULL DEFAULT '' COMMENT '对手信息',
  `create_time` datetime NOT NULL,
  `process_status_id` int(11) NOT NULL DEFAULT '1' COMMENT ' 1进行中，3表示完结。与solo主表一致',
  PRIMARY KEY (`id`),
  UNIQUE KEY `solo_id_2` (`solo_id`,`user_id`),
  KEY `solo_id` (`solo_id`),
  KEY `match_date` (`match_date`),
  KEY `user_id` (`user_id`),
  KEY `process_status_id` (`process_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=721 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `if_stock_mm_user`;
CREATE TABLE `if_stock_mm_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `stock_money_match_id` bigint(20) NOT NULL,
  `match_date` date NOT NULL COMMENT '比赛日',
  `user_id` bigint(20) NOT NULL,
  `money_ing` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '可用资金',
  `money_end` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '收盘资金',
  `amount` int(11) NOT NULL DEFAULT '0' COMMENT '交易单数',
  `amount_win` int(11) NOT NULL DEFAULT '0',
  `his_money_ceil` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '历史最高资金',
  `his_money_floor` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '历史最低资金',
  `reborn` int(11) NOT NULL DEFAULT '0' COMMENT '重生次数',
  `point` int(11) NOT NULL DEFAULT '0' COMMENT '已兑换的分数',
  `point_time` int(11) NOT NULL DEFAULT '0' COMMENT '兑换次数',
  `profit` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '比赛盈利',
  `stock_money_earn` decimal(11,0) NOT NULL DEFAULT '0' COMMENT '获取的实盘资金奖励',
  `gold_margin` int(11) NOT NULL DEFAULT '0' COMMENT '金币门票',
  `create_time` datetime NOT NULL,
  `process_status_id` int(11) NOT NULL DEFAULT '1' COMMENT ' 1进行中，3表示完结。与主表一致',
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_money_match_id_2` (`stock_money_match_id`,`user_id`),
  KEY `stock_money_match_id` (`stock_money_match_id`),
  KEY `match_date` (`match_date`),
  KEY `user_id` (`user_id`),
  KEY `process_status_id` (`process_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `if_stock_money_match`;
CREATE TABLE `if_stock_money_match` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `match_date` date NOT NULL COMMENT '比赛日',
  `money_start` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '起始资金',
  `gold` int(11) NOT NULL DEFAULT '0' COMMENT '单个用户的门票',
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `person_amount` int(11) NOT NULL DEFAULT '0' COMMENT '报名人数',
  `process_status_id` int(11) NOT NULL DEFAULT '0' COMMENT '0报名中， 1进行中，3表示完结，2结算中',
  PRIMARY KEY (`id`),
  KEY `match_date` (`match_date`),
  KEY `end_time` (`end_time`),
  KEY `process_status_id` (`process_status_id`),
  KEY `start_time` (`start_time`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `if_trade`;
CREATE TABLE `if_trade` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `contract_no` varchar(50) NOT NULL COMMENT '合约编号',
  `direction` int(11) NOT NULL COMMENT '交易方向  1看多，-1看空',
  `buy_price` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '买入价',
  `sell_price` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '卖出价',
  `profit` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '盈利',
  `buy_time` datetime NOT NULL COMMENT '买入时间',
  `sell_time` datetime NOT NULL COMMENT '卖出时间',
  `stop_loss_point` decimal(20,2) NOT NULL DEFAULT '0.00',
  `process_status_id` int(11) NOT NULL DEFAULT '1' COMMENT '点买状态  1进行中，3表示完结',
  `ref_table` varchar(50) NOT NULL DEFAULT '',
  `ref_id` bigint(20) NOT NULL DEFAULT '-1',
  `match_date` date NOT NULL,
  `reborn` int(11) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ref_table` (`ref_table`,`ref_id`),
  KEY `process_status_id` (`process_status_id`),
  KEY `match_date` (`match_date`),
  KEY `ref_table_2` (`ref_table`)
) ENGINE=InnoDB AUTO_INCREMENT=106461 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `news`;
CREATE TABLE `news` (
  `newsID` bigint(20) NOT NULL DEFAULT '0',
  `newsTitle` varchar(100) DEFAULT NULL,
  `newsSummary` varchar(200) DEFAULT NULL,
  `newsBody` mediumtext,
  `newsURL` varchar(200) DEFAULT NULL,
  `newsOriginSource` varchar(200) DEFAULT NULL,
  `newsAuthor` varchar(50) DEFAULT NULL,
  `newsPublishSite` varchar(100) DEFAULT NULL,
  `newsInsertTime` datetime DEFAULT NULL,
  `newsPublishTime` datetime DEFAULT NULL,
  PRIMARY KEY (`newsID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `sys_user`;
CREATE TABLE `sys_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_name` varchar(15) NOT NULL,
  `login_pwd` char(32) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login_name` (`login_name`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user`;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `login_pwd` varchar(32) NOT NULL DEFAULT '' COMMENT '登录密码',
  `mobile` char(11) NOT NULL DEFAULT '' COMMENT '手机号，一个月内改一次',
  `qq_open_id` varchar(50) NOT NULL DEFAULT '',
  `wx_open_id` varchar(50) NOT NULL DEFAULT '',
  `sina_open_id` varchar(50) NOT NULL DEFAULT '',
  `nick_name` varchar(15) NOT NULL DEFAULT '',
  `gold` bigint(20) NOT NULL DEFAULT '0' COMMENT '10钻石=200金币',
  `diamond` bigint(20) NOT NULL DEFAULT '0' COMMENT '1rmb=10钻石',
  `stock_money` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '实盘资金，可兑换操盘、可以兑换话费等',
  `money_deposit` bigint(20) NOT NULL DEFAULT '0' COMMENT '充值的rmb总额',
  `create_time` datetime NOT NULL COMMENT '注册时间',
  `delete_flag` int(11) NOT NULL DEFAULT '0',
  `if_daily_free_amount` bigint(20) NOT NULL DEFAULT '0' COMMENT '掘金单数',
  `if_daily_free_amount_win` bigint(20) NOT NULL DEFAULT '0' COMMENT '掘金单盈',
  `if_daily_free_reborn` int(11) NOT NULL DEFAULT '0' COMMENT '掘金重生',
  `if_daily_free_gold` bigint(20) NOT NULL DEFAULT '0' COMMENT '掘金金币',
  `guide_prize` int(11) NOT NULL DEFAULT '0' COMMENT '新手奖励',
  `nick_name_prize` int(11) NOT NULL DEFAULT '0' COMMENT '新手奖励',
  `if_daily_free_amount_prize` int(11) NOT NULL DEFAULT '0' COMMENT '新手奖励',
  `if_daily_free_gold_prize` int(11) NOT NULL DEFAULT '0' COMMENT '新手奖励',
  `if_daily_free_reborn_prize` int(11) NOT NULL DEFAULT '0' COMMENT '新手奖励',
  `if_solo_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '当前是否处于solo中。0表示常态，大于0表示比赛中',
  `if_solo_amount` int(11) NOT NULL DEFAULT '0' COMMENT '比赛场次',
  `if_solo_amount_win` int(11) NOT NULL DEFAULT '0' COMMENT '胜利场次',
  `if_solo_gold_margin` bigint(20) NOT NULL DEFAULT '0' COMMENT '斗牛押注金币',
  `if_solo_gold_win` bigint(20) NOT NULL DEFAULT '0' COMMENT '斗牛盈利金币',
  `if_solo_max_win_len` int(20) NOT NULL DEFAULT '0' COMMENT '斗牛最长连胜',
  `if_solo_win_len` int(20) NOT NULL DEFAULT '0' COMMENT '斗牛当前连胜',
  `if_solo_find_time` datetime DEFAULT NULL COMMENT '开始寻找对手的时间，if_solo_id<0时有效',
  `if_solo_refuse` int(20) NOT NULL DEFAULT '0' COMMENT '1表示拒绝指定挑战',
  `if_stock_money_id` bigint(20) NOT NULL DEFAULT '-1' COMMENT '当前是否处于match中。0表示常态，大于0表示比赛的id',
  `if_stock_money_amount` bigint(20) NOT NULL DEFAULT '0' COMMENT '比赛场次',
  `if_stock_money_reborn` int(11) NOT NULL DEFAULT '0' COMMENT '夺宝重生',
  `if_stock_money_earn` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '夺宝赚取的资金',
  PRIMARY KEY (`id`),
  KEY `mobile` (`mobile`) USING BTREE,
  KEY `qq_open_id` (`qq_open_id`) USING BTREE,
  KEY `wx_open_id` (`wx_open_id`) USING BTREE,
  KEY `sina_open_id` (`sina_open_id`) USING BTREE,
  KEY `create_time` (`create_time`),
  KEY `nick_name` (`nick_name`),
  KEY `if_solo_id` (`if_solo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=857 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_deposit_his`;
CREATE TABLE `user_deposit_his` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `number` varchar(50) NOT NULL,
  `deposit_src_id` int(11) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `money` bigint(11) NOT NULL,
  `info` varchar(200) NOT NULL DEFAULT '',
  `create_time` datetime NOT NULL,
  `sys_user_id` int(11) NOT NULL DEFAULT '-1' COMMENT '用于清算补充',
  PRIMARY KEY (`id`),
  UNIQUE KEY `number` (`number`),
  KEY `user_id` (`user_id`),
  KEY `create_time` (`create_time`),
  KEY `deposit_src_id` (`deposit_src_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_diamond_change`;
CREATE TABLE `user_diamond_change` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `money_flow_id` int(11) NOT NULL,
  `diamond` bigint(20) NOT NULL,
  `final_diamond` bigint(20) NOT NULL COMMENT '变动后用户的余额',
  `info` varchar(200) NOT NULL DEFAULT '',
  `ref_table` varchar(50) NOT NULL DEFAULT '',
  `ref_id` bigint(50) NOT NULL DEFAULT '-1' COMMENT '方案ID',
  `create_time` datetime NOT NULL,
  `sys_user_id` int(11) NOT NULL DEFAULT '-1' COMMENT '用于清算补充',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `money_flow_id` (`money_flow_id`),
  KEY `create_time` (`create_time`),
  KEY `ref_table` (`ref_table`,`ref_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_gift`;
CREATE TABLE `user_gift` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `gift` varchar(100) NOT NULL,
  `info` varchar(100) NOT NULL,
  `create_time` datetime NOT NULL,
  `ref_table` varchar(50) NOT NULL DEFAULT '',
  `ref_id` bigint(50) NOT NULL DEFAULT '-1' COMMENT '方案ID',
  `process_status_id` int(11) NOT NULL DEFAULT '1',
  `remark` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `create_time` (`create_time`),
  KEY `ref_table` (`ref_table`),
  KEY `ref_id` (`ref_id`),
  KEY `process_status_id` (`process_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_gift_sys`;
CREATE TABLE `user_gift_sys` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT '-1',
  `gift` varchar(100) NOT NULL DEFAULT '',
  `info` varchar(100) NOT NULL DEFAULT '',
  `ref_table` varchar(50) NOT NULL DEFAULT '',
  `get_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ref_table` (`ref_table`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_gold_change`;
CREATE TABLE `user_gold_change` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `money_flow_id` int(11) NOT NULL,
  `gold` bigint(20) NOT NULL,
  `final_gold` bigint(20) NOT NULL COMMENT '变动后用户的余额',
  `info` varchar(200) NOT NULL DEFAULT '',
  `ref_table` varchar(50) NOT NULL DEFAULT '',
  `ref_id` bigint(50) NOT NULL DEFAULT '-1' COMMENT '方案ID',
  `create_time` datetime NOT NULL,
  `sys_user_id` int(11) NOT NULL DEFAULT '-1' COMMENT '用于清算补充',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `money_flow_id` (`money_flow_id`),
  KEY `create_time` (`create_time`),
  KEY `ref_table` (`ref_table`,`ref_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20488 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_login_his`;
CREATE TABLE `user_login_his` (
  `id` bigint(20) NOT NULL,
  `login_date` date NOT NULL,
  `login_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_mobile`;
CREATE TABLE `user_mobile` (
  `mobile` char(11) NOT NULL DEFAULT '',
  PRIMARY KEY (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_nick_name`;
CREATE TABLE `user_nick_name` (
  `nick_name` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`nick_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_qq_open_id`;
CREATE TABLE `user_qq_open_id` (
  `qq_open_id` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`qq_open_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_sina_open_id`;
CREATE TABLE `user_sina_open_id` (
  `sina_open_id` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`sina_open_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_stock_money_change`;
CREATE TABLE `user_stock_money_change` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `money_flow_id` int(11) NOT NULL,
  `money` decimal(20,2) NOT NULL,
  `final_money` decimal(20,2) NOT NULL COMMENT '变动后用户的余额',
  `info` varchar(200) NOT NULL DEFAULT '',
  `ref_table` varchar(50) NOT NULL DEFAULT '',
  `ref_id` bigint(50) NOT NULL DEFAULT '-1' COMMENT '方案ID',
  `create_time` datetime NOT NULL,
  `sys_user_id` int(11) NOT NULL DEFAULT '-1' COMMENT '用于清算补充',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `money_flow_id` (`money_flow_id`),
  KEY `create_time` (`create_time`),
  KEY `ref_table` (`ref_table`,`ref_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_wx_open_id`;
CREATE TABLE `user_wx_open_id` (
  `wx_open_id` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`wx_open_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1;

